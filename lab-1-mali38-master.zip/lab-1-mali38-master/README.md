# Lab 1 — Reproducible research with RMarkdown and Github

> This first lab will serve as a general introduction to the major tools and platforms that we will be using throughout the semester, which are R, RStudio, and Git/Github.
>
> Instructions for Lab 1: https://labs.cds101.com/Lab1.html
